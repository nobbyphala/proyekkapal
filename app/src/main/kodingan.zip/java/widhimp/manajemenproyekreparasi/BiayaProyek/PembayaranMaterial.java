package widhimp.manajemenproyekreparasi.BiayaProyek;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import widhimp.manajemenproyekreparasi.R;

public class PembayaranMaterial extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.biayaproyek_pembayaranmaterial);
    }
}
