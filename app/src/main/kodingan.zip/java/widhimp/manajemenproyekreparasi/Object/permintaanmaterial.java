package widhimp.manajemenproyekreparasi.Object;

/**
 * Created by Widhi Mahaputra on 12/31/2016.
 */

public class permintaanmaterial {
    String no, nama, spesifikasi, jumlah, tanggaldibutuhkan;

    public permintaanmaterial(String no, String nama, String spesifikasi, String jumlah, String tanggaldibutuhkan) {
        this.no = no;
        this.nama = nama;
        this.spesifikasi = spesifikasi;
        this.jumlah = jumlah;
        this.tanggaldibutuhkan = tanggaldibutuhkan;
    }

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getSpesifikasi() {
        return spesifikasi;
    }

    public void setSpesifikasi(String spesifikasi) {
        this.spesifikasi = spesifikasi;
    }

    public String getTanggaldibutuhkan() {
        return tanggaldibutuhkan;
    }

    public void setTanggaldibutuhkan(String tanggaldibutuhkan) {
        this.tanggaldibutuhkan = tanggaldibutuhkan;
    }
}
