package widhimp.manajemenproyekreparasi.Object;

/**
 * Created by Widhi Mahaputra on 12/4/2016.
 */

public class repairlist {
    private String nama;
    public repairlist(String nama){
        this.nama=nama;
    }
    public String getNama(){return nama;}
}
