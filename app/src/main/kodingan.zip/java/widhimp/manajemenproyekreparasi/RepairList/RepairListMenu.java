package widhimp.manajemenproyekreparasi.RepairList;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import widhimp.manajemenproyekreparasi.Activity.EditkapalActivity;
import widhimp.manajemenproyekreparasi.Activity.SigninActivity;
import widhimp.manajemenproyekreparasi.Inbox;
import widhimp.manajemenproyekreparasi.KirimPesan;
import widhimp.manajemenproyekreparasi.R;

public class RepairListMenu extends AppCompatActivity {
    private Button repairlist, tambahpekerjaan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.repairlist_menu);
        repairlist=(Button)findViewById(R.id.repairlist_repairlist);
        tambahpekerjaan=(Button)findViewById(R.id.tambahpekerjaan_repairlist);
        repairlist.setOnClickListener(operasi);
        tambahpekerjaan.setOnClickListener(operasi);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menutop,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.inbox:
                Intent intentinbox=new Intent(getBaseContext(),Inbox.class);
                startActivity(intentinbox);
                break;
            case R.id.logout:
                Intent intentlogout=new Intent(getBaseContext(),SigninActivity.class);
                startActivity(intentlogout);
                break;
            case R.id.kirimpesan:
                Intent intentpesan=new Intent(getBaseContext(),KirimPesan.class);
                startActivity(intentpesan);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent(getBaseContext(),EditkapalActivity.class);
        startActivity(intent);
    }

    View.OnClickListener operasi=new View.OnClickListener(){
        @Override
        public void onClick(View view){
            switch(view.getId()){
                case R.id.repairlist_repairlist:
                    openRepair();
                    break;
                case R.id.tambahpekerjaan_repairlist:
                    openTambah();
                    break;
            }
        }
    };
    public void openRepair(){
        Intent intent=new Intent(getBaseContext(),RepairlistActivity.class);
        startActivity(intent);
    }
    public void openTambah(){
        Intent intent=new Intent(getBaseContext(),TambahPekerjaan.class);
        startActivity(intent);
    }
}
