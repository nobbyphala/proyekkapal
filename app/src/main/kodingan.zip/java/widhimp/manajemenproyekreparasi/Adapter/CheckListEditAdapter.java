package widhimp.manajemenproyekreparasi.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

import widhimp.manajemenproyekreparasi.MutuProyek.CheckListEdit;
import widhimp.manajemenproyekreparasi.Object.checklist;
import widhimp.manajemenproyekreparasi.Object.checklistedit;
import widhimp.manajemenproyekreparasi.R;

/**
 * Created by Widhi Mahaputra on 1/2/2017.
 */

public class CheckListEditAdapter extends ArrayAdapter<checklistedit> {
    public CheckListEditAdapter(Context context, int resource, List<checklistedit> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final checklistedit listkapal = getItem(position);
        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.mutuproyek_checklist_edit_item,parent,false);
        }
        final TextView name=(TextView) convertView.findViewById(R.id.nama_checklist_edit_item);
        final TextView status=(TextView) convertView.findViewById(R.id.status_checklist_edit_item);
        final TextView komen=(TextView) convertView.findViewById(R.id.komen_checklist_edit_item);
        name.setText(listkapal.getNama());
        status.setText(listkapal.getStatus());
        komen.setText(listkapal.getKomentar());
        return convertView;
    }
}
