package widhimp.manajemenproyekreparasi.Database;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import widhimp.manajemenproyekreparasi.Adapter.QaqcAdapter;
import widhimp.manajemenproyekreparasi.Adapter.ResikoAdapter;
import widhimp.manajemenproyekreparasi.Object.qaqc;
import widhimp.manajemenproyekreparasi.Object.resiko;

/**
 * Created by nobby phala on 28/12/2016.
 */

public class AmbilResiko extends ArrayList<resiko> {
    public static final String JSON_ARRAY = "result";
    public static String[] no, nama, potensi, resiko, penanganan;
    private JSONArray resikoarr = null;
    private String json;

    public AmbilResiko(String json) {
        this.json = json;
    }

    public void ambilresiko(ResikoAdapter resikoAdapter){
        JSONObject jsonObject=null;
        try {
            jsonObject = new JSONObject(json);
            resikoarr=jsonObject.getJSONArray(JSON_ARRAY);
            no= new String[resikoarr.length()];
            nama= new String[resikoarr.length()];
            potensi= new String[resikoarr.length()];
            resiko= new String[resikoarr.length()];
            penanganan= new String[resikoarr.length()];
            for(int i=0;i<resikoarr.length();i++){
                JSONObject jo = resikoarr.getJSONObject(i);
                no[i]=jo.getString("id_resiko");
                nama[i] = jo.getString("nama_kegiatan");
                potensi[i]=jo.getString("potensi_bahaya");
                resiko[i]=jo.getString("resiko");
                penanganan[i]=jo.getString("penanganan_resiko");
                resikoAdapter.add(new resiko(no[i], nama[i],potensi[i],resiko[i],penanganan[i]));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
